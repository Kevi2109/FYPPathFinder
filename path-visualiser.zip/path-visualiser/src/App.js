import logo from './logo.svg';
import React from 'react';
import './App.css';
import PVisualiser from './PVisualiser/PVisualiser';

function App() {
  return (
    <div className="App">
      <PVisualiser> </PVisualiser>
    </div>
  );
}

export default App;
